if __name__ == '__main__':
    a = int(input())
    b = int(input())
    x = a//b
    y = float(a/b)
    print(x)
    print(y)
