if __name__ == '__main__':
    a = int(input())
    b = int(input())
    x=a+b
    y=a-b
    z=a*b
    print(x)
    print(y)
    print(z)
